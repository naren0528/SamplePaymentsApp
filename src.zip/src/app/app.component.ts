import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
    /*template: `<app-registration></app-registration>`*/
    templateUrl:'./app.component.html'
})
export class AppComponent  { name = 'Angular'; }
